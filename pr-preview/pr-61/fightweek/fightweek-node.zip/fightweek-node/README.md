# Fightweek — Node.js UFC schedule

Requires Node.js 22+. No dependencies or API key. Uses ESPN's public feed (an unofficial integration without a guaranteed stable API).

```sh
npm link
ufc schedule
ufc next
ufc this weekend
ufc next weekend
ufc "this weekend"
ufc card "Walker"
ufc schedule --search "Jones"
ufc this weekend --tz America/Denver
ufc schedule --json
```

Without installing: `node cli.js this weekend`, or on Windows `./ufc.cmd this weekend`. These work even if npm is not installed. `npm link` makes the `ufc` command available via your npm global bin directory. If the earlier Python command is installed, uninstall that package with `python -m pip uninstall ufc-schedule-cli` to avoid a name collision, or use `node cli.js`.

## Weekends and dates

Weekends run Friday 00:00 through Monday 00:00, exclusive, in your computer's timezone. This weekend is the Friday–Sunday of the current Monday-based week, including the current weekend on Saturday/Sunday. Next weekend is seven days later. On Monday, this weekend means the coming Friday. Events marked completed are excluded; in-progress events may remain listed.

`--tz America/Denver` selects an IANA timezone. `--utc` overrides it. Date selection uses the chosen timezone, including daylight-saving changes. `--from YYYY-MM-DD` overrides the reference date. `--days 1..366` controls the general schedule window (default 180); weekend windows are always three days. `--search NAME` filters event and fighter names. `card` accepts a name or ID; omitted means the nearest listed event. JSON output is an array with UTC timestamps; no matches produces `[]`. Invalid arguments/provider failures return exit code 1; successful/empty results return 0.

## Website

`npm start` (or `node server.js`), then open http://localhost:3000. The website fetches fresh ESPN data directly and shares date/filtering logic with the CLI. Includes weekend tabs, fighter search, expandable cards, usage examples, copy buttons, and a source download. Internet access is needed. Fonts fall back to system fonts if unavailable. Static website files are in `dist/`.

Event times are provider-listed starts, not main-event walkouts. Fight order is provider order, not a guaranteed running order. Cards and times may change.

## Checks

`npm test` runs Node's built-in test runner. No install step required.
